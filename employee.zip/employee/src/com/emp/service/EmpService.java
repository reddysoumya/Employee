package com.emp.service;

import com.emp.dtobean.Bean;
import com.emp.exception.EmpException;
import com.emp.dao.IEmpDao;

import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.emp.dao.EmpDao;
import com.emp.dtobean.Bean;
import com.emp.exception.EmpException;

public class EmpService implements IEmpService{
	/*Logger log=Logger.getmyLogger();
	PropertyConfigurator.configure("resources/log4j.properties");*/
	EmpDao edao=null;
	@Override
	public int storeEmployee(Bean employee) throws EmpException {
		// TODO Auto-generated method stub
			edao=new EmpDao();
			int retId=edao.storeEmployee(employee);
			System.out.println(retId);
			return retId;
	}
	
	@Override
	public List<Bean> getAllRec() throws EmpException {
		// TODO Auto-generated method stub
edao=new EmpDao();
return edao.getAllRec();

	}

	@Override
	public Bean retriveById(int uid) throws EmpException {
		// TODO Auto-generated method stub
		edao=new EmpDao();
		Bean reId= new Bean();
		return edao.getAllDetailsById(uid);
	}
	
	public boolean validQuantity(int quantity) {
		if(quantity==1)
		{
			return true;
		}
		else {
			System.out.println("you are requested to enter only one quantity");
			return false;
		}
	}
	

public boolean validid(String id) throws EmpException {
	Pattern p1=Pattern.compile("[Ee]{1}[Mm]{1}[Pp]{1}[0-9]{3}");
	Matcher m1=p1.matcher(id);
	if(m1.matches())
	{
		return true;
	}else
	{
		System.out.println("please enter the employee-id in correct format");
		return false;
	}
}
public boolean validname(String name) throws EmpException {
	Pattern p2=Pattern.compile("[A-Z][a-z]{3,}");
	Matcher m2=p2.matcher(name);
	if(m2.matches())
	{
		return true;
	}else
	{
		System.out.println("please enter the name corectly");
		return false;
	}
}
	public boolean validnumber(String number) throws EmpException {
		Pattern p3=Pattern.compile("[6-9][0-9]{9}");
		Matcher m3=p3.matcher(number);
		if(m3.matches())
		{
			return true;
		}else
		{
			System.out.println("please enter the valid number");
			return false;
		}
}
}
