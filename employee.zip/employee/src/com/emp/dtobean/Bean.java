package com.emp.dtobean;

public class Bean {
	
	private int assetid;
	private String assetname;
private int quantity;
private String empid;
private String empname;
private String number;
private String date;


public int getAssetid() {
	return assetid;
}
public void setAssetid(int assetid) {
	this.assetid = assetid;
}
public String getAssetname() {
	return assetname;
}
public void setAssetname(String assetname) {
	this.assetname = assetname;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public String getEmpid() {
	return empid;
}
public void setEmpid(String empid) {
	this.empid = empid;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public Bean(int assetid, String assetname, int quantity, String empid, String empname, String number, String date) {
	super();
	this.assetid = assetid;
	this.assetname = assetname;
	this.quantity = quantity;
	this.empid = empid;
	this.empname = empname;
	this.number = number;
	this.date = date;
}

public Bean(String assetname, int quantity, String empid, String empname, String number) {
	super();
	this.assetname = assetname;
	this.quantity = quantity;
	this.empid = empid;
	this.empname = empname;
	this.number = number;
}
public Bean(String empid, String empname, String number, String date) {
	super();
	this.empid = empid;
	this.empname = empname;
	this.number = number;
	this.date = date;
}
public Bean() {
	super();
	// TODO Auto-generated constructor stub
}
public Bean(int assetid, int quantity, String empid, String empname, String number, String date) {
	super();
	this.assetid = assetid;
	this.quantity = quantity;
	this.empid = empid;
	this.empname = empname;
	this.number = number;
	this.date = date;
}

public Bean(String assetname, int quantity, String empid, String empname, String number, String date) {
	super();
	this.assetname = assetname;
	this.quantity = quantity;
	this.empid = empid;
	this.empname = empname;
	this.number = number;
	this.date = date;
}
@Override
public String toString() {
	return "Bean [assetid=" + assetid + ", assetname=" + assetname + ", quantity=" + quantity + ", empid=" + empid
			+ ", empname=" + empname + ", number=" + number + ", date=" + date + "]";
}


}
