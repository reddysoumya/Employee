package com.emp.service;

import java.util.List;

import com.emp.dtobean.Bean;
import com.emp.exception.EmpException;
import com.emp.exception.EmpException;

public interface IEmpService {
	public boolean validid(String id) throws EmpException;
	public abstract int storeEmployee(Bean employee)throws EmpException;
	public abstract List<Bean> getAllRec()throws EmpException;
	Bean retriveById(int uid) throws EmpException;
}
