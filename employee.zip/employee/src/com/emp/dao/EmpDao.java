package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.emp.dtobean.Bean;
import com.emp.exception.EmpException;
import com.emp.dao.IQueryMapper;
import com.emp.exception.EmpException;
import com.emp.util.EmpUitl;
public class EmpDao implements IEmpDao{
	Connection conn=null;

	@Override
	public int storeEmployee(Bean employee) throws EmpException {
		// TODO Auto-generated method stub
		int status=0;
		conn=EmpUitl.getDbConnection();
		try {
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.EMPLOYEE_INSERT_QRY);
			pst.setString(1,employee.getAssetname());
			/*pst.setInt(2, employee.getAssetid());*/
			pst.setInt(2,employee.getQuantity());
			pst.setString(3,employee.getEmpid());
			pst.setString(4,employee.getEmpname());
			pst.setString(5,employee. getNumber());
			//pst.setString(6, employee.getDate());
			status=pst.executeUpdate();
			
		} catch (SQLException e) {
			//log.error("handling");
			throw new EmpException("data not stored "+e.getMessage());
		}
		
		return status;
	}

	@Override
	public List<Bean> getAllRec() {
		// TODO Auto-generated method stub
			conn=EmpUitl.getDbConnection();
				List<Bean>cusList=null;
				try {
					Statement st=conn.createStatement();
					ResultSet rs=st.executeQuery(IQueryMapper.EMPLOYEE_INSERT_QRY1);
					cusList=new ArrayList();
					Bean rb=null;
				while(rs.next())
				{
					rb=new Bean(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
					cusList.add(rb);
				}
				}catch(SQLException e) {
					try {
						throw new EmpException("couldn't Retrivedate from db: "+e.getMessage());
					} catch (EmpException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				return cusList;
	}

	@Override
	public Bean getAllDetailsById(int uid) throws EmpException {
		// TODO Auto-generated method stub
		conn=EmpUitl.getDbConnection();
		Bean rb1=null;
		try {
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.EMPLOYEE_INSERT_QRY2);
			pst.setInt(1, uid);
			ResultSet rs = pst.executeQuery();
			
		while(rs.next())
		{
			rb1=new Bean(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
		}
		}catch(SQLException e) {
			throw new EmpException("couldn't Retrivedate from db: "+e.getMessage());}
		return rb1;
}
	
	
	
}
