package com.emp.ui;

import java.util.List;
import java.util.Scanner;

import com.emp.dtobean.Bean;
import com.emp.exception.EmpException;
import com.emp.service.EmpService;
import com.emp.service.IEmpService;
import com.emp.dtobean.Bean;
import com.emp.exception.EmpException;
import com.emp.service.EmpService;

public class Presentation {
	static EmpService empser=null;
	static Scanner scan=null;
public static void main(String[] args) throws EmpException {
	System.out.println("***--employee--**");
	System.out.println("------------------");
	System.out.println("1-> Insert details");
	System.out.println("2-> retriveall");
	System.out.println("3-> retrivebyid");
	System.out.println("4-> exit");
	System.out.println("---------------");
	scan=new Scanner(System.in);
	int option=scan.nextInt();
	switch(option){
	
	case 1:
		boolean result;
		boolean res1;
		boolean res2;
		boolean res3;
		String id;
		int quantity;
		String name;
		String number;
		empser=new EmpService();
		System.out.println("Enter Asset Name");
		String aname=scan.next();
		do {
		System.out.println("Enter quantity");
		quantity=scan.nextInt();
		res1=empser.validQuantity(quantity);
		}
		while(res1==false);
		
		
		do
		{
		System.out.println("Enter Employee_Id ");
		id=scan.next();
			result=empser.validid(id);
		}
		while(result==false);
		
		
		do{
			System.out.println("Enter Employee Name");
		 name=scan.next();
		 res2=empser.validname(name);
		}while(res2==false);
		
		
		do {
		System.out.println("Enter Mobile Number");
		number=scan.next();
		res3=empser.validnumber(number);
		}while(res3==false);
		
		
		//System.out.println("Enter Allocation Date");
		//String date=scan.next();
		Bean emp=new Bean(aname,quantity,id,name,number);
		
		 int res=0;
			try {
				res = addEmployeeInfo(emp);
			} 
			catch (EmpException e) {
			
			System.out.println(e.getMessage());
			}
				if(res>0){
				System.out.println("asset is allocated for "+id +"-"+name);
			}
			else
			{
				System.out.println("data is not stored");
			}
			break;
		
	case 2:
		List<Bean> finList=null;
		try {
			finList = retrieveAllRecInfo();
		} catch (EmpException e) {
			
			System.out.println(e.getMessage());
		}
	/*	Iterator it=finList.iterator();
		while(it.hasNext()){
			System.out.println(it.next());
		}*/
		
		for(Bean rec1:finList)
		{
		System.out.println(rec1);	
		}
		break;
	case 3:
		Bean finalObj=null;
		System.out.println("Enter empId that you want to fetch details");
		       int uid=scan.nextInt();
		       finalObj=getDetailsById(uid);
		       System.out.println(finalObj);
		break;
	case 4:
	
		break;
	}
}
	private static Bean getDetailsById(int uid) throws EmpException {
	// TODO Auto-generated method stub
			empser=new EmpService();
			Bean rb= new Bean();
			return empser.retriveById(uid);
	}
	private static List<Bean> retrieveAllRecInfo() throws EmpException {
	// TODO Auto-generated method stub
empser=new EmpService();
		
		return empser.getAllRec();
}

	public static int addEmployeeInfo(Bean emp) throws EmpException{
		//delegate the call to method in service - also pass the data
		empser=new EmpService();
		int result=empser.storeEmployee(emp);
		return result;
	}

}