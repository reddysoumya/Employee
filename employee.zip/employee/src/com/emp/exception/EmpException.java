package com.emp.exception;

public class EmpException extends Exception {
	public EmpException() {
		
	}
	public EmpException(String msg) {
		super(msg);
	}

}
