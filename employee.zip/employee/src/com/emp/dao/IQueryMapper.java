package com.emp.dao;

public class IQueryMapper {
	public static final String EMPLOYEE_INSERT_QRY="insert into asset values(seq_1.nextval,?,?,?,?,?,SYSDATE)";
	public static String EMPLOYEE_INSERT_QRY1="select * from asset";
	public static final String EMPLOYEE_INSERT_QRY2="SELECT * FROM asset WHERE aid=?";
}
